package gapp.model.dao;

import java.util.List;

import gapp.model.AdditionRecord;
import gapp.model.User;

public interface AdditionRecordDao {

	List<AdditionRecord> getrecord(int id);
	
	AdditionRecord saveRecord(AdditionRecord record);
	
	 AdditionRecord getRecord( Integer id );
}
