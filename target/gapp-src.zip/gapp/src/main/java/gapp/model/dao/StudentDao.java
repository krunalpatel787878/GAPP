package gapp.model.dao;

import java.util.List;


import gapp.model.Student;
import gapp.model.User;

public interface StudentDao {

	List<Student> getStudents();
	
	List<Student> getStudent(String email);
	
	Student saveStudent( Student stu );
	
	Student getStudentByApp(int appid);
}
