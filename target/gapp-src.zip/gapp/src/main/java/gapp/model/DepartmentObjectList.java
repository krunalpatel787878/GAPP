package gapp.model;

public class DepartmentObjectList {
	
	int count;
	int id;
	
	public DepartmentObjectList(int c,int i) {
		this.count=c;
		this.id=i;
	}
	
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	

}
