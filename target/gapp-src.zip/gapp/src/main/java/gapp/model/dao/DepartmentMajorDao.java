package gapp.model.dao;

import java.util.List;

import gapp.model.DepartmentMajor;


public interface DepartmentMajorDao {

	
	List<DepartmentMajor> getMajor(int id);
	
	List<Object[]> getNumberMajor();
	
	DepartmentMajor saveDepartmentMajor(DepartmentMajor departmentMajor);
	
	Integer removeMajor(int id);
	
	DepartmentMajor getMajorByDept(int id);
	
	List<DepartmentMajor> getProgrambyAjax(int id);
	
	DepartmentMajor getDepartmentMajor(int id);
	
}
