package gapp.model.dao;

import java.util.List;

import gapp.model.EducationInfo;
import gapp.model.User;



public interface EducationInfoDao {
	
	List<EducationInfo> getEducationInfo(String email);
	
	List<EducationInfo> getEducationInfoByApplicationid(int id);
	
	EducationInfo get( int id );
	
	EducationInfo saveInfo( EducationInfo info );
	
}
